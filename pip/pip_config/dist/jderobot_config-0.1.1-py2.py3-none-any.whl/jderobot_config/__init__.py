__author__ = 'aitormf'

## import simplification
# empty __init__.py:
#   from jderobotconfig import config as config
# new option:
#   import jderobotconfig as config
from .config import *

from .properties import Properties

